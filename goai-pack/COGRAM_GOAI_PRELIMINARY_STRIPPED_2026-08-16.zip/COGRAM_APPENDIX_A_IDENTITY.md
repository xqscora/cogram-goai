# Cogram — Agent Identity List（Appendix A · stripped）

> 手册 Appendix A 字段：Name · Role · Capabilities · Inputs · Outputs · Dependencies · Decision Boundary · Trace  
> **阉割版** — 无护城河能力描述。对外作品名 = **Cogram**。

**Scenario:** 教学级软件 issue 协作（假数据 monorepo）  
**Baseline:** AgentTeams-style role orchestration（设计对齐，非生产部署）  
**Live repo:** https://github.com/xqscora/cogram-goai — this file in a zip is a snapshot.

---

## Agent 1

| Field | Value |
|-------|-------|
| **Name** | `triage-clerk` |
| **Role** | Incident intake & task decomposition |
| **Capabilities** | 解析 issue 文本；输出 2–3 个自然语言子任务与粗 token 预算。**不能**改代码、**不能**调用记忆以外的写工具 |
| **Inputs** | `issue_text`, optional `severity` |
| **Outputs** | `{ subtasks: string[], budget_tokens: number }` |
| **Dependencies** | AgentTeams-style controller slot；下游依赖 `keyword-memory` |
| **Decision Boundary** | 仅路由与拆分；高风险操作一律不触发 |
| **Trace** | 写 `run.jsonl`：`agent=triage-clerk`, inputs hash, subtasks |

---

## Agent 2

| Field | Value |
|-------|-------|
| **Name** | `keyword-memory` |
| **Role** | Shared sticky-note recall |
| **Capabilities** | 调用 Skill `cogram.keyword_recall`；返回匹配便签。**不能**做语义向量检索、**不能**访问密钥路径 |
| **Inputs** | `issue_text`, `max_notes` |
| **Outputs** | `{ notes[], matched_tags[], bands[] }` |
| **Dependencies** | Skill `cogram.keyword_recall`；本地 `notes.json` |
| **Decision Boundary** | 只读；空结果时降级为 `manual_search` 标志，不编造笔记 |
| **Trace** | 记录 matched_tags、note ids、latency_ms |

---

## Agent 3

| Field | Value |
|-------|-------|
| **Name** | `checklist-verifier` |
| **Role** | Lightweight verification & experience capture |
| **Inputs** | `subtasks`, `notes`, optional `test_checklist` |
| **Outputs** | `{ pass: bool, checklist: [], audit_id }`；若 pass 则追加一条关键词便签（含 `cited`） |
| **Capabilities** | 对照静态 checklist；写审计行。**不能**自动 merge |
| **Dependencies** | 上游 A1/A2 输出；Human approval gate |
| **Decision Boundary** | `pass=true` 仍须 **Human confirm** 才算闭环完成 |
| **Trace** | checklist 每项勾选 + audit_id；经验写入仅明文 tags |

---

## Collaboration graph

```
triage-clerk → keyword-memory → checklist-verifier → HUMAN → (optional note append)
```

---

## Skill one-liner（配套 Appendix B 可另表）

| Skill | One-liner |
|---|---|
| `cogram.keyword_recall` | synonym-aware keyword notes, evidence bands |
| `cogram.evidence_bind` | subtask → unique evidence or fail |
| `cogram.redact` | strip secret-shaped spans before append |
| `cogram.approval_gate` | no human yes → no write |
| `cogram.path_guard` | refuse `.env` / `secret` / `token` / `id_rsa` / `.pem` |

All five are callable without the rest of the pipeline (`cogram-goai tools`).
