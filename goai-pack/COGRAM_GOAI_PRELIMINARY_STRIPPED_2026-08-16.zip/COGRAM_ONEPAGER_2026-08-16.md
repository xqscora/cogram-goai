# Cogram — One-pager (Agent Infra)

**Cora Zeng** · xqscora@gmail.com · Team **Cogram** (solo) · GOAI 2026 Agent Infra  
Official topic: Direction 3 — end-to-end software collaboration

## What
Three agents share **cited** keyword memory. The next agent does not re-scan the repo. Nothing is written without a human yes. Rollback keeps the audit row.

## Why
Incident loops fail when context is an uncited dump and “fixes” have no evidence.

## Loop
Issue → A1 triage → A2 `keyword_recall` → cited packet → A3 `evidence_bind` → human gate → capture / rollback.

## Skills
`keyword_recall` · `evidence_bind` · `redact` · `approval_gate` · `path_guard`

## Evidence
Hash-chained JSONL. `cogram-goai verify-trace --complete`.

## Open
Apache-2.0, zero runtime deps, 81 tests, public CI.  
https://github.com/xqscora/cogram-goai — **this is the live copy**. The zip is a dated snapshot (`45685af`, 2026-08-16) and is updated less often.
