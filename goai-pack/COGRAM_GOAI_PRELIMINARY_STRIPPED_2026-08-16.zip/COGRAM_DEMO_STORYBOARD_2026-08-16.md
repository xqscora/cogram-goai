# Cogram — demo storyboard (silent OK)

> Optional for preliminary. Run from the **GitHub clone**, not from this zip.

```bash
cogram-goai demo --auto-approve --trace run.jsonl
cogram-goai demo --conflict --auto-approve --no-capture
cogram-goai verify-trace --trace run.jsonl --complete
```

| t | Screen | Show |
|---|--------|------|
| 0:00 | Title | Cogram public slice · 3 agents · 5 skills · Direction 3 |
| 0:20 | Roles | triage-clerk → keyword-memory → checklist-verifier → human |
| 0:50 | Issue | large upload timeout after second retry |
| 1:10 | Skill 1 | `cogram.keyword_recall` returns cited high-band notes |
| 1:40 | Packet | only `high` auto-injected; conflict empties auto-inject |
| 2:00 | Skill 2 | `cogram.evidence_bind` — reused evidence fails the later item |
| 2:20 | Gate | human approve; capture stores `cited`; rollback keeps the row |
| 2:40 | Trace | `verify-trace --complete` + hash chain |
| 2:55 | End | Cora Zeng · Agent Infra · https://github.com/xqscora/cogram-goai |

GitHub is the live copy. This zip is a dated snapshot.
