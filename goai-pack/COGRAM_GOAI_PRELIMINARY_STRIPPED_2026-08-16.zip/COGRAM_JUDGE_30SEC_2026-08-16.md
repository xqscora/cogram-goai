# Cogram — Judge 30-sec card (Agent Infra)

**Cora Zeng** · xqscora@gmail.com · Team **Cogram** (solo) · GOAI 2026 Agent Infra  
Official topic: **Direction 3 — end-to-end software collaboration**

| Q | A |
|---|---|
| What | Three agents share **cited** memory so the next one does not re-scan the repo or write without evidence |
| Loop | A1 triage → A2 keyword_recall → A3 evidence_bind → human gate → capture / rollback |
| Skills | five contracts: recall, evidence_bind, redact, approval_gate, path_guard |
| Exceptions | conflict empties auto-inject; reused evidence fails; no yes → no write |
| Evidence | hash-chained JSONL · `verify-trace --complete` |
| Open | Apache-2.0, 0 deps, 81 tests, public CI |
| Repository | https://github.com/xqscora/cogram-goai — **live copy**. This zip is a dated snapshot (`45685af`). |
