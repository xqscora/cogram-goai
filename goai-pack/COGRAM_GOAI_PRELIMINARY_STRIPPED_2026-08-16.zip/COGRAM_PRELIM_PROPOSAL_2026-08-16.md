# Cogram — GOAI 2026 Agent Infra preliminary proposal

**Author:** Cora Zeng · xqscora@gmail.com  
**Team:** Cogram (solo)  
**Track:** Agent Infra  
**Official topic:** Direction 3 — End-to-end Software Development Collaboration  
**Date:** 2026-08-16  
**Repo (live):** https://github.com/xqscora/cogram-goai  
**Frozen in this zip:** `45685af` · v0.3.3 · 2026-08-16  
**License:** Apache-2.0 · **runtime deps:** none · **tests:** 81 · **CI:** Ubuntu/Windows × Python 3.9/3.12

> **GitHub vs zip.** The public repository on `main` is updated continuously. This zip is a dated snapshot and is rebuilt less often. If a number, command, or SHA here disagrees with GitHub, **trust GitHub**.

This is the **public competition slice**. It is not the product. See repo `docs/SCOPE.md`.

Scoring source: [Agent Infra track page](https://www.goaihz.com/en/tracks/agent-infra) (Beijing Time). Preliminary = direction + solution. Code is optional now; the repo is already there so a reviewer can check claims.

---

## 1. Scenario and value (25%)

| Official ask | This entry |
|---|---|
| Real, representative problem | A software incident (timeout / retry / missing test) that several people will touch |
| Target users | on-call engineers, reviewers, student project teams — anyone who must *not* write a “fix” with no evidence |
| Pain | Multi-agent tools re-scan the repo, dump uncited context, and write memory back without a human |
| Value | Knowledge capture with citations; failed checklist instead of a silent skip; rollback that still audits |
| Replicable | Same loop on any issue text + note JSON. Demo issue is a large-upload timeout after the second retry |

This is the official **Direction 3** loop: defect in → decompose → locate from memory → verify → confirm → capture.

---

## 2. Multi-agent closed loop (25%)

Agents never call each other. `run_pipeline` is the only orchestrator, so the trace is complete by construction.

```
issue → A1 triage_clerk → A2 keyword_memory → cited context packet
      → A3 checklist_verifier → HUMAN gate → A2 capture / rollback
```

| AgentTeams baseline (name is not scored) | Cogram mapping |
|---|---|
| Role orchestration | A1 / A2 / A3 + human; each has a written decision boundary in `docs/AGENT_IDENTITY.md` |
| Task decomposition | A1 emits 2–3 budgeted subtasks (`reproduce` / `locate` / `fix_with_test` / `secure` …) |
| Context passing | packet with note ids, evidence bands, causes — not an uncited blob |
| Collaborative execution | A2 recall → A3 verify → human → A2 write |
| State tracking | append-only JSONL with `prev_hash` / `hash`; `verify-trace --complete` |

### Exception branches

| Exception | What happens |
|---|---|
| Two `high` notes disagree on cause | `auto_inject` emptied; citations still visible |
| Evidence missing, or the same sentence reused | that subtask fails; the run does not write |
| No approver | `approved=None`, `gate_pending`, no write |
| Capture of the same issue+cause+fix | not appended twice |
| Note-store path looks like a secret | `path_guard` refuses |

High-risk action = writing memory. The only license is `cogram.approval_gate`. Rollback sets `status=rolled_back`; the row stays.

---

## 3. Skill system (25%)

Skill is mandatory on this track. Five contracts, printed by `cogram-goai tools`. Inputs / outputs / failure are explicit. Any agent or a CI job can call the same function.

| Skill | In | Out | Failure / refuse |
|---|---|---|---|
| `cogram.keyword_recall` | issue text + notes | ranked notes + band + fallback | miss → `manual_search`, no invented note |
| `cogram.evidence_bind` | subtasks + `{id: evidence}` | checklist | missing or reused evidence fails the later item |
| `cogram.redact` | note text | redacted text | secret-shaped spans stripped before append |
| `cogram.approval_gate` | verified + human yes/no | `allowed` | no yes → no write |
| `cogram.path_guard` | store path | ok / refuse | `.env` / `secret` / `token` / `id_rsa` / `.pem` |

Reuse: A2 and the CLI both call recall; A3 and CI both call `evidence_bind`. Versioning here is the public git tag + the JSON contract, not a cloud marketplace. Official Alibaba Cloud Skills are **not** required; contracts are replaceable (track note: necessity and replaceability, not product count).

---

## 4. Engineering, evidence, security (20%)

| Official ask | Where a judge checks |
|---|---|
| Runnable | `pip install -e .` then `cogram-goai demo --auto-approve --trace run.jsonl` |
| Dependencies | none at runtime |
| Trace / logs | JSONL; `replay`; `verify-trace --complete` requires `task_input`, `decomposition`, `verification`, and a gate event |
| Sample I/O | README sample + `examples/issues/flaky_upload_timeout.txt` |
| Approval / rollback / audit | gate + `rollback` + hash chain |
| Secrets | redact-on-capture + path denylist |
| Conflict / fallback | `--conflict` demo; recall never hallucinates |

CI runs the handbook commands: unit tests, capturing demo, `verify-trace --complete`, conflict demo.

---

## 5. Open-source (5%)

Apache-2.0. Skill catalog is JSON. `docs/SCOPE.md` lists what is **not** in this entry (no vector DB, no graph memory, no decay mechanics, no file:line routing, no cloud auth, no license keys). Third-party runtime dependencies: none.

---

## Feasibility / implementation plan

| Now (prelim) | Semi-final 9/3 if advanced |
|---|---|
| Three agents, five skills, cited packet, hash-chained trace, 81 tests, public CI | Keep the same loop; add one more issue fixture + a one-minute recorded demo of `demo` + `verify-trace --complete` |
| No model call | Still no model call unless a reviewer asks for an optional LLM wrapper *outside* the scored skills |

---

## Reproduce

```bash
pip install -e .
python -m unittest discover tests -v
cogram-goai demo --auto-approve --trace run.jsonl
cogram-goai demo --conflict --auto-approve --no-capture
cogram-goai replay --trace run.jsonl
cogram-goai verify-trace --trace run.jsonl --complete
cogram-goai tools
```
