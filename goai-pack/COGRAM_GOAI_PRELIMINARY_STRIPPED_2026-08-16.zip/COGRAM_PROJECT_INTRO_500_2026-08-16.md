# Cogram — official Project Introduction (≤500 characters)

Paste **one** language into the GOAI portal field. Counts checked 2026-08-16.

Source for the field: [Agent Infra track page](https://www.goaihz.com/en/tracks/agent-infra) — “Project Introduction / Yes / Text, within 500 characters including punctuation.”

**Versioning:** GitHub `main` is the live copy and keeps moving. Any zip in this pack is a **dated snapshot** and is updated less often. If they disagree, trust the repo.

## English (470 characters)

```
Cogram is Agent Infra for software incidents (official Direction 3). Pain: agents re-scan the repo and write without evidence. Loop: A1 decomposes; A2 recalls cited notes only; A3 binds unique evidence; a human must approve; rollback keeps the audit row. Five reusable skill contracts; conflict empties auto-inject; hash-chained JSONL. Apache-2.0, 0 deps, 81 tests, public CI. GitHub is the live copy; this zip is a dated snapshot. https://github.com/xqscora/cogram-goai
```

## 中文（295 字，含标点与 URL）

```
Cogram 做软件事故的多 agent 闭环，对应官网 Direction 3（端到端研发协作）。痛点：多 agent 反复扫仓库、无证据就写回，知识无法复用。方案：A1 分诊拆任务，A2 只召回带引用的笔记，A3 绑定互不复用的证据；高风险写回必须人工批准，回滚保留审计行。冲突时清空自动注入；无批准则 pending；路径守卫拒绝密钥文件。创新：五个可复用 Skill 契约，哈希链 JSONL 可验伪。开源：Apache-2.0，零依赖，81 测，CI 绿。GitHub 持续更新，本 zip 为日期快照。https://github.com/xqscora/cogram-goai
```

## What this sentence set covers

| Official ask | Where in the text |
|---|---|
| Problem + scenario | software incidents / Direction 3 |
| Core solution | A1 → A2 cited memory → A3 unique evidence → human gate → rollback |
| Innovation | skill contracts, conflict empties auto-inject, hash-chained JSONL |
| Open / reusable value | Apache-2.0, zero deps, public CI |
| Current progress | 81 tests, green CI, public repo URL |
| Versioning | GitHub live / zip snapshot |
