# Cogram — GOAI Agent Infra preliminary pack (2026-08-16 snapshot)

**Author:** Cora Zeng `<xqscora@gmail.com>`  
**Team:** Cogram (solo)  
**Track:** Agent Infra · official topic **Direction 3** (end-to-end software collaboration)

## GitHub is live. This zip is a snapshot.

| | |
|---|---|
| **Live copy (trust this if they disagree)** | https://github.com/xqscora/cogram-goai |
| **Frozen in this zip** | `45685af` · v0.3.3 · 2026-08-16 |
| **How often each updates** | GitHub: continuously. Zip: only when we rebuild a pack. |

Do not treat this attachment as the latest code. Clone the repository.

## What is in this zip

| File | Use |
|---|---|
| `COGRAM_PRELIM_PROPOSAL_2026-08-16.md` | Full prelim proposal mapped to 25/25/25/20/5 |
| `COGRAM_PRELIMINARY_SUBMIT_2026-08-16.pdf` | Same argument, printable |
| `COGRAM_PRELIMINARY_DECK_STRIPPED_2026-08-16.pdf` | Landscape slides |
| `COGRAM_AgentInfra_Prelim_FILLED_STRIPPED_2026-08-16.pptx` | Official template, filled |
| `COGRAM_PROJECT_INTRO_500_2026-08-16.md` | Portal ≤500-character field |
| `COGRAM_JUDGE_30SEC_2026-08-16.md` / `COGRAM_ONEPAGER_2026-08-16.md` | Short cards |
| `COGRAM_APPENDIX_A_IDENTITY.md` | Three-agent identity |
| `COGRAM_DEMO_STORYBOARD_2026-08-16.md` | Optional demo timing |

## Run (from the GitHub clone, not from this zip)

```bash
pip install -e .
python -m unittest discover tests -v
cogram-goai demo --auto-approve --trace run.jsonl
cogram-goai verify-trace --trace run.jsonl --complete
```

Apache-2.0. Zero runtime deps. 81 tests. Public CI. Scope: educational multi-agent slice — no commercial auth / cloud / graph memory.
